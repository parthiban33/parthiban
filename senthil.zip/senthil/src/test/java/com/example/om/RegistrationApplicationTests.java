package com.example.om;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.om.entity.Model;
import com.example.om.repository.RegisterRepository;
import com.example.om.service.RegisterService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RegistrationApplicationTests {
  @Autowired
  private RegisterService service;
  @MockBean
  private RegisterRepository repository;
  
  @Test
  public void getUsersTest()
  {
	  when(repository.findAll()).thenReturn(Stream 
			      .of(new Model(12,"prakash","chennai",9960441456l,"pass@word1")).collect(Collectors.toList()));
              assertEquals(1,service.getUsers().size());
  }
  
  @Test
  public void saveUserTest()
  {
	  Model user=new Model(12,"prakash","chennai",9960441456l,"pass@word1");
	  when(repository.save(user)).thenReturn(user);
	  assertEquals("User registered", service.savedata(user));
  }
  @Test
  public void getByUserIdTest()
  {
	  when(repository.findById(12)).thenReturn(Optional
			      .of(new Model(12,"prakash","chennai",9960441456l,"pass@word1")));
	  assertNotNull(service.getById(12).get());
  }
  
  
}
