package com.example.om;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@Order(1)
public class SpringBootAdminSecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {

		auth.inMemoryAuthentication().withUser("employee").password("{noop}employee")
            .authorities("USER").and().withUser("javainuse").password("{noop}javainuse")
            .authorities("USER", "ADMIN");
//		auth.inMemoryAuthentication()
//			.withUser("admin").password("{noop}cskdhoni2020#").roles("admin");
//		auth.inMemoryAuthentication()
//		.withUser("user").password("{noop}password").roles("USER");
	}
//
//	@Override
//	public void configure(HttpSecurity http) throws Exception {
//		http
//			.antMatcher("/**")
//			.authorizeRequests().anyRequest().authenticated()
//			.and().formLogin().loginPage("/index")
//				.defaultSuccessUrl("/user/adminIndex", true)
//			.permitAll()
//			.and().logout().logoutSuccessUrl("/index");
//		
//		http.csrf().disable();
//	}
	@Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/user/register");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests().antMatchers("/**").permitAll().antMatchers("/user/index")
            .hasAnyRole("USER", "ADMIN").antMatchers("/user/list").hasAnyRole("ADMIN")
            .antMatchers("/user/create").hasAnyRole("ADMIN").anyRequest().authenticated().and().formLogin()
            .loginPage("/index")
			.defaultSuccessUrl("/user/adminIndex", true)
		.permitAll()
		.and().logout().logoutSuccessUrl("/index");

        http.csrf().disable();
    }

//    @Autowired
//    public void configureGlobal(AuthenticationManagerBuilder authenticationMgr) throws Exception {
//        authenticationMgr.inMemoryAuthentication().withUser("employee").password("employee")
//            .authorities("ROLE_USER").and().withUser("javainuse").password("javainuse")
//            .authorities("ROLE_USER", "ROLE_ADMIN");
//    }

}
