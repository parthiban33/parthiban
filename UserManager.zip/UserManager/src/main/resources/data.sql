INSERT INTO `roles` (`name`) VALUES ('ADMIN');

INSERT INTO `roles` (`name`) VALUES ('USER');


INSERT INTO `users` (`username`, `password`, `enabled`,`rolenumber`) VALUES ('patrick', '$2a$10$f80MumyMqt5G.vv8Pn1YduLBaYvcg5ZANt.lfKIjyDCnPzyCyu/2i','1',1);

INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (1, 1);