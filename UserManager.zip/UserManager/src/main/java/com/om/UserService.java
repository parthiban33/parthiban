package com.om;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private RoleRepository roleRepo;
	public Iterable<User> listAll() {		
		return userRepo.findAll();
	}
	
	public void save(User user) {
		
		
		Optional<Role> roledetails=roleRepo.findById(user.getRolenumber());
		Set<Role> role=new HashSet<>();
		role.add(roledetails.get());
		user.setRoles(role);
		userRepo.save(user);
	}
	
	public User get(Long id) {
		return userRepo.findById(id).get();
	}
	
	public void delete(Long id) {
		User user=new User();
		user.setId(id);
		user.setUsername("Avengers");
		user.setPassword("Assemble");
		user.setEnabled(true);
		user.setRolenumber(1);
		userRepo.save(user);
		userRepo.deleteById(id);
	}
}
