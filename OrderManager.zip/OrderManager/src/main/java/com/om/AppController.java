package com.om;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
	@Autowired
	private OrderService service;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Order> orderList = service.listAll();
		model.addAttribute("orderList", orderList);
		
		return "index";
	}
	
	@RequestMapping("/new")
	public String showNewOrderForm(Model model) {
		Order order = new Order();
		model.addAttribute("order", order);
		
		return "new_order";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveOrder(@ModelAttribute("order") Order order) {
		service.save(order);
		
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditOrderForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_order");
		
		Order order = service.get(id);
		mav.addObject("order", order);
		
		return mav;
	}	
	
	@RequestMapping("/delete/{id}")
	public String deleteOrder(@PathVariable(name = "id") Long id) {
		service.delete(id);
		
		return "redirect:/";
	}
}
