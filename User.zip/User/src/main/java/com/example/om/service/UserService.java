package com.example.om.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.om.exception.UserException;
import com.example.om.entity.Model;
import com.example.om.repository.RegisterRepository;

@Service
public class UserService {
	
	@Autowired
	private RegisterRepository registerReposiotry;
		
	public Model create (Model user){
		Model newUser = user;
		return registerReposiotry.saveAndFlush(newUser);
	}
	
	public Model findById(Integer id){
		return registerReposiotry.getOne(id);
	}
	
	public Model update(Model user,Integer id) throws UserException{
		Model updateUser= registerReposiotry.getOne(id);
		if(updateUser == null)
			throw new UserException();
		
		updateUser.setName(user.getName());
		updateUser.setAddress(user.getAddress());
		updateUser.setContactNumber(user.getContactNumber());
		registerReposiotry.saveAndFlush(updateUser);
		return updateUser;
		
	}
	public Optional<Model> delete(Integer id) throws UserException{
		Optional<Model> deleteUser = registerReposiotry.findById(id);
		if(deleteUser == null)
			throw new UserException();
		registerReposiotry.deleteById(id);
		return deleteUser;
	}
	
	public List<Model> findAllUsers(){
		return registerReposiotry.findAll();
	}
	
	
}
