package com.example.om.controller;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.example.om.exception.UserException;
import com.example.om.entity.Model;
import com.example.om.service.UserService;

@Controller
@RequestMapping(value="/user")
public class WebController {
	@Autowired
	private RestTemplate template;

	@Autowired
	private UserService userServices;
	
	@RequestMapping(value= "/", method=RequestMethod.GET)
	public ModelAndView index(){
		return new ModelAndView("index");
	}
	
	@RequestMapping(value="/adminIndex", method=RequestMethod.GET)
	public ModelAndView adminIndex(){
		return new ModelAndView("adminIndex");
	}
	@RequestMapping(value="/create",method=RequestMethod.GET)
	public ModelAndView createNewUser(){
		ModelAndView mav = new ModelAndView("user-create","user",new Model());
		return mav;
	}
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public ModelAndView submitNewUser(@ModelAttribute Model user){
		ModelAndView mav = new ModelAndView();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String rawPassword = user.getPassword();
		String encodedPassword = encoder.encode(rawPassword);
		user.setPassword(encodedPassword);
		userServices.create(user);
		mav.setViewName("redirect:/user/adminIndex");
		return mav;
		
	}
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView retrieveListOfUser(){
		ModelAndView mav = new ModelAndView("user-list");
		List<Model> userList = userServices.findAllUsers();
		mav.addObject("userList",userList);
		return mav;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
	public ModelAndView retrieveEditUser(@PathVariable Integer id){
		ModelAndView mav = new ModelAndView("user-edit");
		Model user = userServices.findById(id);
		mav.addObject("user", user);
		return mav;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.POST)
	public ModelAndView submitEditUser(@ModelAttribute Model user, @PathVariable Integer id) throws UserException{
		ModelAndView mav = new ModelAndView();
		userServices.update(user,id);
		 mav.setViewName("redirect:/user/adminIndex");
		return mav;
	}
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.GET)
	public ModelAndView deleteUser(@PathVariable Integer id) throws UserException{
		ModelAndView mav = new ModelAndView();
		userServices.delete(id);
		mav.setViewName("redirect:/user/adminIndex");
		return mav;
	}
	
}
