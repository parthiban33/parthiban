package com.example.om;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.om.entity.Activity;

import com.example.om.repository.ActivityRepository;
import com.example.om.service.ActivityService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ActivityApplicationTests {
	@Autowired
	  private ActivityService service;
	  @MockBean
	  private ActivityRepository repository;
	  
	  @Test
	  public void getOrderTest()
	  {
		  when(repository.findAll()).thenReturn(Stream 
				      .of(new Activity(12l,"loading","chennai","coimbatore",3)).collect(Collectors.toList()));
	              assertEquals(1,service.getOrder().size());
	  }
	  
	  @Test
	  public void saveOrderTest()
	  {
		  Activity order=new Activity(12l,"loading","chennai","coimbatore",3);
		  when(repository.save(order)).thenReturn(order);
		  assertEquals("Order saved", service.savedata(1,order));
	  }
	  @Test
	  public void getByOrderidTest() throws Exception 
	  {
		  when(repository.findById(12l)).thenReturn(Optional
				      .of(new Activity(12l,"loading","chennai","coimbatore",3)));
		  assertNotNull(service.activitydata(12l).get());
	  }

}
