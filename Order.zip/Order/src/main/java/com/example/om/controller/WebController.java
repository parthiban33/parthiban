package com.example.om.controller;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.example.om.exception.OrderException;
import com.example.om.WebSecurityConfiguration;
import com.example.om.entity.Activity;
import com.example.om.entity.Model;
import com.example.om.service.OrderServices;

@Controller
@RequestMapping(value="/order")
public class WebController {

	@Autowired
	private OrderServices orderServices;
	@Autowired
	private WebSecurityConfiguration config;
	
	@RequestMapping(value= {"/"}, method=RequestMethod.GET)
	public ModelAndView index(){
		try {
			config.auth1.inMemoryAuthentication()
			.withUser("parthiban").password("{noop}csk").roles("USER");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("index");
	}
	@RequestMapping(value="/adminIndex",method=RequestMethod.GET)
	public ModelAndView adminIndex(){
		return new ModelAndView("adminIndex");
	}
	@RequestMapping(value="/create",method=RequestMethod.GET)
	public ModelAndView createNewOrder(){
		ModelAndView mav = new ModelAndView("order-create","order",new Activity());
		return mav;
	}
	@RequestMapping(value="/createUser",method=RequestMethod.POST)
	public ModelAndView submitNewUser(@ModelAttribute Model user){
		ModelAndView mav = new ModelAndView();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String rawPassword = user.getPassword();
		String encodedPassword = encoder.encode(rawPassword);
		user.setPassword(encodedPassword);
		orderServices.create(user);
		mav.setViewName("redirect:/user/adminIndex");
		return mav;
		
	}
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public void submitNewOrder(@ModelAttribute Activity order){
		orderServices.create(order);
		
	}
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView retrieveListOfOrder(){
		ModelAndView mav = new ModelAndView("order-list");
		List<Activity> orderList = orderServices.findAllOrders();
		mav.addObject("orderList",orderList);
		return mav;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
	public ModelAndView retrieveEditOrder(@PathVariable Long id){
		ModelAndView mav = new ModelAndView("order-edit");
		Activity order = orderServices.findById(id);
		mav.addObject("order", order);
		return mav;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.POST)
	public ModelAndView submitEditOrder(@ModelAttribute Activity order, @PathVariable Long id) throws OrderException{
		ModelAndView mav = new ModelAndView();
		 orderServices.update(order,id);
		 mav.setViewName("redirect:/order/adminIndex");
		return mav;
	}
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.GET)
	public ModelAndView deleteOrder(@PathVariable Long id) throws OrderException{
		ModelAndView mav = new ModelAndView();
		 orderServices.delete(id);
		mav.setViewName("redirect:/order/adminIndex");
		return mav;
	}
	
}
