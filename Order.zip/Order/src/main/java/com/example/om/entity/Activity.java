package com.example.om.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="ACTIVITY_TB")
public class Activity {
 @Id 
 @GeneratedValue(strategy=GenerationType.AUTO)
	private long orderId;
	private String activityType;
	private String origin;
	private String destination;
	private int intermediateStops;
	
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public String getActivityType() {
		return activityType;
	}
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getIntermediateStops() {
		return intermediateStops;
	}
	public void setIntermediateStops(int intermediateStops) {
		this.intermediateStops = intermediateStops;
	}
	public Activity(long orderId, String activityType, String origin, String destination, int intermediateStops) {
		super();
		this.orderId = orderId;
		this.activityType = activityType;
		this.origin = origin;
		this.destination = destination;
		this.intermediateStops = intermediateStops;
	}
	public Activity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
