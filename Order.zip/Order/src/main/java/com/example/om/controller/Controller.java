package com.example.om.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.example.om.entity.Activity;

import com.example.om.service.ActivityService;


@RestController
@RequestMapping("/OM")
public class Controller {
	
	@Autowired
	private ActivityService service;
	@Autowired
	private RestTemplate template;
	@PostMapping("/activity/{userId}")
	public String activityUpdate(@PathVariable ("userId") int userId,@RequestBody Activity data)
	{
		return service.savedata(userId,data);
	}
	@GetMapping("/getOrder")
	public List<Activity> findAllUsers()
	{
		return service.getOrder();
	}
	@DeleteMapping("/deleteOrder/{orderid}")
	public String deleteData(@PathVariable ("orderid") long orderid)
	{
		return service.deleteOrder(orderid);
	}
	@PutMapping(path="/update/{orderid}")
	public String updateOrder(@PathVariable ("orderid")long orderid,@RequestBody Activity data) {
	    return service.updateOrderData(orderid,data);
	    }
	@GetMapping("/filter_by_orderid/{orderid}")
	public Optional<Activity> filterByOrderid(@PathVariable ("orderid") long orderid)  
	{
		return service.activitydata(orderid);
		 
	}
	@SuppressWarnings("unchecked")
	@GetMapping("/Load/{loadid}")
	public Optional<Activity> invokeload(@PathVariable ("loadid") long loadid)
	{
		String url="http://LOAD-SERVICE/OM/filter_by_loadid/"+loadid;
		return template.getForObject(url, Optional.class);
	}
}
