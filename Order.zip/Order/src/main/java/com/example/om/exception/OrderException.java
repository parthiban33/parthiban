package com.example.om.exception;

@SuppressWarnings("serial")
public class OrderException extends Exception{
	
	
}
