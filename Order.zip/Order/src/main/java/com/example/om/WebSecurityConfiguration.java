package com.example.om;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@Scope("singleton")
@Order(1)
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {
	public AuthenticationManagerBuilder auth1;
	
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		this.auth1=auth;
		auth.inMemoryAuthentication()
			.withUser("admin").password("{noop}cskdhoni2020#").roles("ADMIN");
		auth.inMemoryAuthentication()
		.withUser("user").password("{noop}password").roles("USER");
		
		
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
	    http
	      .csrf().disable()
	      .authorizeRequests()
	      .antMatchers("/order/adminIndex").hasAnyRole("ADMIN","USER")
	      .antMatchers("/order/list").hasAnyRole("ADMIN","USER")
	      .antMatchers("/order/edit/**").hasAnyRole("ADMIN")
	      .antMatchers("/order/delete/**").hasAnyRole("ADMIN")
	      .antMatchers("/h2-console/**").permitAll()
	      .mvcMatchers("/order/adminIndex").authenticated()
	      .and()
	      .formLogin()
	      .loginPage("/index")
	      .defaultSuccessUrl("/order/adminIndex", true)
	      .permitAll()
	      .and()
	      .logout()
	      .logoutSuccessUrl("/index")
	      .and()
			.exceptionHandling().accessDeniedPage("/403");
	}
	@Override
    public void configure(WebSecurity web) throws Exception {
        web
            .ignoring()
            .antMatchers("/h2-console/**");
    }
	
}
