package com.example.om.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.om.exception.OrderException;
import com.example.om.entity.Activity;
import com.example.om.entity.Model;
import com.example.om.repository.ActivityRepository;
import com.example.om.repository.RegisterRepository;

@Service
public class OrderServices {
	
	@Autowired
	private ActivityRepository orderReposiotry;
	@Autowired
	private RegisterRepository userRepo;
		
	public Activity create (Activity order){
		Activity newOrder = order;
		return orderReposiotry.saveAndFlush(newOrder);
	}
	public Model create (Model user){
		Model newUser = user;
		return userRepo.saveAndFlush(newUser);
	}
	
	public Activity findById(Long id){
		return orderReposiotry.getOne(id);
	}
	
	public Activity update(Activity order,Long id) throws OrderException{
		Activity updateOrder= orderReposiotry.getOne(id);
		if(updateOrder == null)
			throw new OrderException();
		
		updateOrder.setActivityType(order.getActivityType());
		updateOrder.setOrigin(order.getOrigin());
		updateOrder.setDestination(order.getDestination());
		updateOrder.setIntermediateStops(order.getIntermediateStops());
		orderReposiotry.saveAndFlush(updateOrder);
		return updateOrder;
		
	}
	public Optional<Activity> delete(Long id) throws OrderException{
		Optional<Activity> deleteOrder = orderReposiotry.findById(id);
		if(deleteOrder == null)
			throw new OrderException();
		orderReposiotry.deleteById(id);
		return deleteOrder;
	}
	
	public List<Activity> findAllOrders(){
		return orderReposiotry.findAll();
	}
	
	
}
