package com.example.om.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.om.entity.Activity;

import com.example.om.repository.ActivityRepository;


@Service
public class ActivityService {
@Autowired
	private ActivityRepository repository;

@Autowired
private RestTemplate template;

public String savedata(int userId,Activity data)
{
	String url="http://REGISTRATION-SERVICE/OM/findById/"+userId;
	
	 if(template.getForObject(url, Optional.class).isPresent())
	 {
		 
	repository.save(data);
	return "Order saved for userId "+userId;
	 }
	 else
		 return "Invalid userId";
	 }
public Optional<Activity> activitydata(long orderid) 
{
	Optional<Activity> order= repository.findById(orderid);
	return order;
}
public List<Activity> getOrder()
{
	return repository.findAll();
}
public String deleteOrder(long orderid) {
	Optional<Activity> order= repository.findById(orderid);
	if(order.isPresent())
	{
		repository.deleteById(orderid);
		return "Order deleted";
	}
	else
		return "Invalid orderid";
	
	
}
public String updateOrderData(long orderid,Activity data) {
	Optional<Activity> order= repository.findById(orderid);
	if(order.isPresent())
	{
	repository.save(data);
	return "Order updated";
	}
	else
		return "Invalid orderid";
}
}
