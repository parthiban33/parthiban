package com.example.om;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.om.entity.LoadStatus;
import com.example.om.repository.LoadRepository;
import com.example.om.service.LoadService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LoadApplicationTests {

	@Autowired
	  private LoadService service;
	  @MockBean
	  private LoadRepository repository;
	  
	  @Test
	  public void getLoadTest()
	  {
		  when(repository.findAll()).thenReturn(Stream 
				      .of(new LoadStatus(12l,"20km","5km",3)).collect(Collectors.toList()));
	              assertEquals(1,service.getLoad().size());
	  }
	  
	  @Test
	  public void saveLoadTest()
	  {
		  LoadStatus load=new LoadStatus(12l,"20km","5km",3);
		  when(repository.save(load)).thenReturn(load);
		  assertEquals("Load created", service.savedata(1l, load));
	  }
	  @Test
	  public void getByLoadidTest()
	  {
		  when(repository.findById(12l)).thenReturn(Optional
				      .of(new LoadStatus(12l,"20km","10km",2)));
		  assertNotNull(service.loaddata(12l).get());
	  }
}
