package com.example.om.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.om.exception.LoadException;
import com.example.om.entity.LoadStatus;
import com.example.om.repository.LoadRepository;

@Service
public class LoadManagementService {
	
	@Autowired
	private LoadRepository loadReposiotry;
		
	public LoadStatus create (LoadStatus load){
		LoadStatus newLoad = load;
		return loadReposiotry.saveAndFlush(newLoad);
	}
	
	public LoadStatus findById(Long id){
		return loadReposiotry.getOne(id);
	}
	
	public LoadStatus update(LoadStatus load,Long id) throws LoadException{
		LoadStatus updateLoad= loadReposiotry.getOne(id);
		if(updateLoad == null)
			throw new LoadException();
		
		updateLoad.setRouteDistance(load.getRouteDistance());
		updateLoad.setTraveledDistance(load.getTraveledDistance());
		updateLoad.setCurrentStop(load.getCurrentStop());
		loadReposiotry.saveAndFlush(updateLoad);
		return updateLoad;
		
	}
	public Optional<LoadStatus> delete(Long id) throws LoadException{
		Optional<LoadStatus> deleteLoad = loadReposiotry.findById(id);
		if(deleteLoad == null)
			throw new LoadException();
		loadReposiotry.deleteById(id);
		return deleteLoad;
	}
	
	public List<LoadStatus> findAllLoad(){
		return loadReposiotry.findAll();
	}
	
	
}
