package com.example.om.controller;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.example.om.exception.LoadException;
import com.example.om.entity.LoadStatus;
import com.example.om.service.LoadManagementService;;

@Controller
@RequestMapping(value="/load")
public class WebController {

	@Autowired
	private LoadManagementService loadServices;
	
	@RequestMapping(value= {"/"}, method=RequestMethod.GET)
	public ModelAndView index(){
		return new ModelAndView("index");
	}
	@RequestMapping(value="/adminIndex",method=RequestMethod.GET)
	public ModelAndView adminIndex(){
		return new ModelAndView("adminIndex");
	}

	@RequestMapping(value="/userLogin",method=RequestMethod.GET)
	public ModelAndView userlogin() {
		return new ModelAndView("userLogin");
	}
	@RequestMapping(value="/userIndex",method=RequestMethod.GET)
	public ModelAndView userdashboard() {
		return new ModelAndView("userIndex");
	}
	
	@RequestMapping(value="/create",method=RequestMethod.GET)
	public ModelAndView createNewLoad(){
		ModelAndView mav = new ModelAndView("load-create","load",new LoadStatus());
		return mav;
	}
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public ModelAndView submitNewLoad(@ModelAttribute LoadStatus load){
		ModelAndView mav = new ModelAndView();
		loadServices.create(load);
		mav.setViewName("redirect:/load/adminIndex");
		return mav;
		
	}
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView retrieveListOfLoad(){
		ModelAndView mav = new ModelAndView("load-list");
		List<LoadStatus> loadList = loadServices.findAllLoad();
		mav.addObject("loadList",loadList);
		return mav;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
	public ModelAndView retrieveEditLoad(@PathVariable Long id){
		ModelAndView mav = new ModelAndView("load-edit");
		LoadStatus load = loadServices.findById(id);
		mav.addObject("load", load);
		return mav;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.POST)
	public ModelAndView submitEditLoad(@ModelAttribute LoadStatus load, @PathVariable Long id) throws LoadException{
		ModelAndView mav = new ModelAndView();
		loadServices.update(load,id);
		 mav.setViewName("redirect:/load/adminIndex");
		return mav;
	}
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.GET)
	public ModelAndView deleteLoad(@PathVariable Long id) throws LoadException{
		ModelAndView mav = new ModelAndView();
		loadServices.delete(id);
		mav.setViewName("redirect:/load/adminIndex");
		return mav;
	}
	
}
