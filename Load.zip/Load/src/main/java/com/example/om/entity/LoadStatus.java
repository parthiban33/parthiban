package com.example.om.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="LOAD_TB")
public class LoadStatus {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long loadId;
	private String routeDistance;
	private String traveledDistance;
	private int currentStop;
	public long getLoadId() {
		return loadId;
	}
	public void setLoadId(long loadId) {
		this.loadId = loadId;
	}
	public String getRouteDistance() {
		return routeDistance;
	}
	public void setRouteDistance(String routeDistance) {
		this.routeDistance = routeDistance;
	}
	public String getTraveledDistance() {
		return traveledDistance;
	}
	public void setTraveledDistance(String traveledDistance) {
		this.traveledDistance = traveledDistance;
	}
	public int getCurrentStop() {
		return currentStop;
	}
	public void setCurrentStop(int currentStop) {
		this.currentStop = currentStop;
	}
	public LoadStatus(long loadId, String routeDistance, String traveledDistance, int currentStop) {
		super();
		this.loadId = loadId;
		this.routeDistance = routeDistance;
		this.traveledDistance = traveledDistance;
		this.currentStop = currentStop;
	}
	public LoadStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}