package com.example.om.exception;

@SuppressWarnings("serial")
public class LoadException extends Exception{
	
	
}
