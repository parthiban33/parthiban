package com.example.om.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.om.entity.LoadStatus;
import com.example.om.service.LoadService;

@RestController
@RequestMapping("/OM")
public class Controller {
	
	@Autowired
	private LoadService service;
	
	@PostMapping("/load/{orderId}")
	public String load(@PathVariable ("orderId") long orderId,@RequestBody LoadStatus data)
	{
		return service.savedata(orderId,data);
	}
	@GetMapping("/getload")
	public List<LoadStatus> findAllUsers()
	{
		return service.getLoad();
	}
	@DeleteMapping("/deleteLoad/{loadid}")
	public String deleteData(@PathVariable ("loadid") long loadid)
	{
		return service.deleteLoad(loadid);
	}
	@PutMapping(path="/update/{loadid}")
	public String updateOrder(@PathVariable ("loadid") long loadid,@RequestBody LoadStatus data) {
	    return service.updateLoadData(loadid,data);
	    }
	@GetMapping("/filter_by_loadid/{loadid}")
	public Optional<LoadStatus> filterByLoadid(@PathVariable ("loadid") long loadid)
	{
		return service.loaddata(loadid);
		
		
	}

}
