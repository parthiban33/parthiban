package com.example.om;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@Order(1)
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication()
			.withUser("admin").password("{noop}cskdhoni2020#").roles("ADMIN");
		auth.inMemoryAuthentication()
		.withUser("user").password("{noop}password").roles("USER");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
	    http
	      .csrf().disable()
	      .authorizeRequests()
	      .antMatchers("/load/adminIndex").hasAnyRole("ADMIN","USER")
	      .antMatchers("/load/list").hasAnyRole("ADMIN","USER")
	      .antMatchers("/load/edit/**").hasAnyRole("ADMIN")
	      .antMatchers("/load/delete/**").hasAnyRole("ADMIN")
	      .antMatchers("/h2-console/**").permitAll()
	      .mvcMatchers("/load/adminIndex").authenticated()
	      .and()
	      .formLogin()
	      .loginPage("/index")
	      .defaultSuccessUrl("/load/adminIndex", true)
	      .permitAll()
	      .and()
	      .logout()
	      .logoutSuccessUrl("/index")
	      .and()
			.exceptionHandling().accessDeniedPage("/403");;
	}
	@Override
    public void configure(WebSecurity web) throws Exception {
        web
            .ignoring()
            .antMatchers("/h2-console/**");
    }
}
