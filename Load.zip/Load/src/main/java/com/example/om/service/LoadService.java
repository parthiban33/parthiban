package com.example.om.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.example.om.entity.LoadStatus;
import com.example.om.repository.LoadRepository;



@Service
public class LoadService {
@Autowired
	private LoadRepository repository;
@Autowired
private RestTemplate restTemplate;


public String savedata(long orderId,LoadStatus data)
{
	
	String url="http://ACTIVITY-SERVICE/OM/filter_by_orderid/"+orderId;
	if(restTemplate.getForObject(url, Optional.class).isPresent())
	{
	 repository.save(data);
	 return "Load created for orderId "+orderId;
	}
	else 
		return  "Load not created";
}
public Optional<LoadStatus> loaddata(long loadid)
{
	Optional<LoadStatus> load= repository.findById(loadid);
	return load;
}
public List<LoadStatus> getLoad()
{
	return repository.findAll();
}
public String deleteLoad(long loadid) {
	Optional<LoadStatus> load=repository.findById(loadid);
	if(load.isPresent())
	{
	repository.deleteById(loadid);
	return "Load deleted";
	}
	else
		return "Invalid loadid";
}
public String updateLoadData(long loadid,LoadStatus data) {
	Optional<LoadStatus> load=repository.findById(loadid);
	if(load.isPresent())
	{
		repository.save(data);
	return "Load updated";
	}
	else
	return "Invalid loadid";
}
}

