INSERT INTO `roles` (`name`) VALUES ('ADMIN');
INSERT INTO `roles` (`name`) VALUES ('USER');



INSERT INTO `users` (`username`, `password`, `enabled`,email) VALUES ('patrick', '$2a$10$hSG9JLs9l1HDHOQ0rdTpLu1IglqvVgmtd1mAZfQIR.rWvhm2NvgAy','1','par@gmail.com');

INSERT INTO `users` (`username`, `password`, `enabled`,email) VALUES ('parthiban', '$2a$10$hSG9JLs9l1HDHOQ0rdTpLu1IglqvVgmtd1mAZfQIR.rWvhm2NvgAy','1','partha@gmail.com');

INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (1, 1);
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (2, 2);