package com.om;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
	@Autowired
	private LoadService service;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Load> loadList = service.listAll();
		model.addAttribute("loadList", loadList);
		
		return "index";
	}
	
	@RequestMapping("/new")
	public String showNewLoadForm(Model model) {
		Load load = new Load();
		model.addAttribute("load", load);
		
		return "new_load";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveLoad(@ModelAttribute("load") Load load) {
		service.save(load);
		
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditLoadForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_load");
		
		Load load = service.get(id);
		mav.addObject("load", load);
		
		return mav;
	}	
	
	@RequestMapping("/delete/{id}")
	public String deleteLoad(@PathVariable(name = "id") Long id) {
		service.delete(id);
		
		return "redirect:/";
	}
}
