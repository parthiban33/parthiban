package com.om;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Load {
	private Long id;
	private String routedistance;
	private String traveleddistance;
	private int currentstop;

	protected Load() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRoutedistance() {
		return routedistance;
	}

	public void setRoutedistance(String routedistance) {
		this.routedistance = routedistance;
	}

	public String getTraveleddistance() {
		return traveleddistance;
	}

	public void setTraveleddistance(String traveleddistance) {
		this.traveleddistance = traveleddistance;
	}

	public int getCurrentstop() {
		return currentstop;
	}

	public void setCurrentstop(int currentstop) {
		this.currentstop = currentstop;
	}

	
	
}
