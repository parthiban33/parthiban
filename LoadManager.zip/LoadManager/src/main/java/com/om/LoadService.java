package com.om;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoadService {
	@Autowired
	private LoadRepository repo;
	
	public List<Load> listAll() {		
		return repo.findAll();
	}
	
	public void save(Load load) {
		repo.save(load);
	}
	
	public Load get(Long id) {
		return repo.findById(id).get();
	}
	
	public void delete(Long id) {
		repo.deleteById(id);
	}
}
